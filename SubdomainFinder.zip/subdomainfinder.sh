#!/usr/bin/env bash
# SubdomainFinder v0.5.4 (modified pretty output)
# Usage: ./subdomainfinder.sh -i domains.txt -o outputs/all-subdomains.txt
# Requires: curl, awk, sort, uniq. jq recommended.

set -euo pipefail
IFS=$'\n\t'

INPUT_FILE=""
OUTFILE="outputs/all-subdomains.txt"
QUIET=0
USER_AGENT="SubdomainFinder/0.5.4 (+https://example.local)"

# Colors (should work in Git Bash)
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
RESET='\033[0m'

print() { [ "$QUIET" -eq 0 ] && printf '%s\n' "$*"; }
print_color() { [ "$QUIET" -eq 0 ] && printf '%b\n' "$1$2$RESET"; }

usage() {
  cat <<EOF
Usage: $0 -i domains.txt [-o output_file] [-q]
  -i input_file    File containing list of domains (one per line)
  -o output_file   Save combined results (default: outputs/all-subdomains.txt)
  -q               Quiet mode
EOF
  exit 1
}

while getopts ":i:o:qh" opt; do
  case ${opt} in
    i) INPUT_FILE=$OPTARG ;;
    o) OUTFILE=$OPTARG ;;
    q) QUIET=1 ;;
    h) usage ;;
    \?) echo "Invalid option: -$OPTARG" >&2; usage ;;
    :) echo "Option -$OPTARG requires an argument." >&2; usage ;;
  esac
done
shift $((OPTIND -1))

[ -z "$INPUT_FILE" ] && echo "Please specify -i domains.txt" >&2 && usage
[ ! -f "$INPUT_FILE" ] && echo "Input file $INPUT_FILE not found!" >&2 && exit 1

mkdir -p "$(dirname "$OUTFILE")"
TMP_DIR=$(mktemp -d -t subfinder.XXXXXX)
CACHE="${TMP_DIR}/cachelista"
DATA="${TMP_DIR}/data.json"
trap 'rm -rf "$TMP_DIR"' EXIT

normalize_file() {
  awk '{print tolower($0)}' "$1" \
    | sed 's/^[[:space:]]*//; s/[[:space:]]*$//; s/^\*\.//; s/^\*//' \
    | sort -u
}

: > "$OUTFILE"
print_color "$CYAN" "🌐 SubdomainFinder v0.5.4 starting..."
printf "📅 Run timestamp: %s\n\n" "$(date -u +"%Y-%m-%dT%H:%M:%SZ")" >> "$OUTFILE"

# temp summary (domain|count)
SUMMARY="${TMP_DIR}/summary.tsv"
: > "$SUMMARY"

while IFS= read -r DOMAIN || [ -n "$DOMAIN" ]; do
  DOMAIN="${DOMAIN%%#*}"
  DOMAIN="${DOMAIN//[[:space:]]/}"
  [ -z "$DOMAIN" ] && continue

  print_color "$YELLOW" "🔍 Scanning domain: $DOMAIN"
  : > "$CACHE"

  # --- 1) crt.sh ---
  curl -sS -A "$USER_AGENT" --max-time 15 "https://crt.sh/?q=%25.${DOMAIN}&output=json" -o "$DATA" || true
  if [ -s "$DATA" ]; then
    if command -v jq >/dev/null 2>&1; then
      jq -r '.[].name_value' "$DATA" >> "$CACHE" || true
    else
      grep -oP '"name_value"\s*:\s*"(.*?)"' "$DATA" | sed -E 's/.*"name_value"\s*:\s*"//; s/"$//' | tr ',' '\n' >> "$CACHE" || true
    fi
  fi

  # --- 2) hackertarget ---
  curl -sS -A "$USER_AGENT" --max-time 15 "https://api.hackertarget.com/hostsearch/?q=${DOMAIN}" -o "$DATA" || true
  [ -s "$DATA" ] && cut -d',' -f1 "$DATA" >> "$CACHE" || true

  # normalize and dedupe for this domain
  PERDOMAIN_TMP="${TMP_DIR}/${DOMAIN//[^a-zA-Z0-9_.-]/_}.txt"
  normalize_file "$CACHE" > "$PERDOMAIN_TMP" || true

  DOMAIN_COUNT=$(wc -l < "$PERDOMAIN_TMP" | tr -d ' ')
  if [ "$DOMAIN_COUNT" -eq 0 ]; then
    print_color "$RED" "⚠️  No subdomains found for $DOMAIN"
    echo -e "${DOMAIN}\t0" >> "$SUMMARY"
    print "-----------------------------------------"
    continue
  fi

  # print nice header + enumerated subdomains
  print_color "$BOLD" "────────── $DOMAIN (found: $DOMAIN_COUNT) ──────────"
  nl -ba -w2 -s'. ' "$PERDOMAIN_TMP" | sed 's/^/   /' | while IFS= read -r line; do
    print "$line"
  done
  print "-----------------------------------------"

  # save per-domain result, and append to combined outfile (we will dedupe at end)
  cp "$PERDOMAIN_TMP" "outputs/${DOMAIN}-subdomains.txt"
  cat "$PERDOMAIN_TMP" >> "$OUTFILE"

  echo -e "${DOMAIN}\t${DOMAIN_COUNT}" >> "$SUMMARY"

done < "$INPUT_FILE"

# final dedupe for combined file
if [ -f "$OUTFILE" ]; then
  sort -u "$OUTFILE" -o "$OUTFILE" || true
fi

# print summary table
print_color "$CYAN" "🎉 Scan complete! Summary per-domain:"
printf "%-35s %10s\n" "DOMAIN" "COUNT"
printf "%-35s %10s\n" "-----------------------------------" "----------"
while IFS=$'\t' read -r d c; do
  printf "%-35s %10s\n" "$d" "$c"
done < "$SUMMARY"

TOTAL=$(wc -l < "$OUTFILE" | tr -d ' ')
print_color "$GREEN" "✅ Total unique subdomains: $TOTAL"
print_color "$GREEN" "📂 Combined results saved to: $PWD/$OUTFILE"
print_color "$GREEN" "📄 Per-domain files: outputs/<domain>-subdomains.txt"
